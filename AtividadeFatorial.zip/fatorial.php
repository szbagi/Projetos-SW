<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $num = $_POST['num'];
    if ($num >= 1 && $num <= 10) {
        $fat = 1;
        for ($i = 1; $i <= $num; $i++) {
            $fat *= $i;
        }
        echo "O fatorial de $num é $fat";
    } else {
        echo "Entrada inválida";
    }
} else {
    echo "Entrada inválida";
}
?>
